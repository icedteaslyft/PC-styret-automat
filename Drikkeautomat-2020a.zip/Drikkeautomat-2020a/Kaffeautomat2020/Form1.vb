﻿Imports System.ComponentModel

Public Class Form1


    'Dette styre en knap, der tilføjer en værdi til variaben "mælk"
    'Den tjekker om "mælk" er mindre end 3, i det tilfælde tilføjer den 1 til "mælk" værdien.
    'når "mælk" har værdien 3, så kan den ikke tilføje mere til "mælk" værdien.
    Private Sub But_Mælk_Click(sender As Object, e As EventArgs) Handles But_Mælk.Click
        If mælk < 3 Then
            mælk += 1

        End If
        Label1.Text = mælk
    End Sub
    'Dette styre en knap der ser om man har valgt kaffe.
    'Den sætter "drik" teksten til "kaffe"
    'kalder metoden "valgtekst()"
    'Fjerner muligheden for at trykke på kaffe knappen.
    'Gør det muligt at trykke på "Te" knappen.

    Private Sub But_Kaffe_Click(sender As Object, e As EventArgs) Handles But_Kaffe.Click
        drik = "kaffe"
        ValgTekst()
        But_Kaffe.Enabled = False
        But_Te.Enabled = True
    End Sub

    'Dette styre en knap der ser om man har valgt Te.
    'Den sætter "drik" teksten til "Te"
    'kalder metoden "valgtekst()"
    'Fjerner muligheden for at trykke på Te knappen.
    'Gør det muligt at trykke på "Kaffe" knappen.
    Private Sub But_Te_Click(sender As Object, e As EventArgs) Handles But_Te.Click
        drik = "te"
        ValgTekst()
        But_Kaffe.Enabled = True
        But_Te.Enabled = False
    End Sub

    ''Den tjekker om teksten "drik" ikke står tomt.
    ''Hvis det er tilfældet, så gemmer den, denne form, og åbner "Form_Automat".
    ''Hvis teksten "drik" står tomt, så kommer der en besked boks op, der gør brugeren
    'opmærksom om, at man ikke har valgt en drik.

    Private Sub But_Bekræft_Click(sender As Object, e As EventArgs) Handles But_Bekræft.Click
        If drik <> Nothing Then
            Form_Automat.Show()
            Me.Hide()
        Else
            MsgBox("Hov! Du har ikke valgt kaffe/te")
        End If

    End Sub

    'Denne lille del kode, gemmer "Form_Automt", så den ikke kommer til at starte ved opstart.

    Private Sub Form1_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        Form_Automat.Hide()
    End Sub


    'Dette styre en knap, der fjerner en værdi til variaben "sukker"
    'Den tjekker om "sukker" er mere end 0, i det tilfælde fjerner den 1 til "sukker" værdien.
    'når "sukker" har værdien 0, så kan den ikke fjerne mere til "sukker" værdien.
    Public Sub But_Fjern_Click(sender As Object, e As EventArgs) Handles But_Fjern.Click
        If sukker > 0 Then
            sukker -= 1
        End If
        Label2.Text = sukker
    End Sub

    'Dette styre en knap, der tilføjer en værdi til variaben "sukker"
    ''Den tjekker om "sukker" er mindre end 3, i det tilfælde tilføjer den 1 til "sukker"
    'værdien.
    'når "sukker" har værdien 3, så kan den ikke tilføje mere til "sukker" værdien.
    Public Sub But_Tilføj_Click(sender As Object, e As EventArgs) Handles But_Tilføj.Click
        If sukker < 3 Then
            sukker += 1
        End If
        Label2.Text = sukker
    End Sub


    ''Denne metode, sætter "label13" tekst til "Du har bestilt " 
    'og hvad end nu "drik" teksten er blevet sat til
    Private Sub ValgTekst()
        Label3.Text = "Du har bestilt " & drik
    End Sub

    'Denne knap nulstiller formens elementer
    'Opdatere formen, uden at lukke den ned
    'sætter variablerne "sukker" og "mælk" til 0
    Private Sub But_Annuller_Click(sender As Object, e As EventArgs) Handles But_Annuller.Click
        Controls.Clear()
        InitializeComponent()
        sukker = 0
        mælk = 0

    End Sub

    'Denne sub slukker "Form_Automat" 
    'Og slukker for K8055 boardet 
    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Form_Automat.Enabled = False
        CloseDevice
    End Sub

    'Tænder for K8055 boardet
    'Og sætter adressen på K8055 boardet.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        OpenDevice(0)

    End Sub
End Class
