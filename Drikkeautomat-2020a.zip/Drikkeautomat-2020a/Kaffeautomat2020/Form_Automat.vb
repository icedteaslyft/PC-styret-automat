﻿Imports System.ComponentModel

Public Class Form_Automat
    ''Angiver "taeller" som et heltal
    Dim taeller As Integer

    ''Starter "Timer1" når "Form_Automat" starter
    Private Sub Form_Automat_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    ''Timeren tilføjer 1 til "taeller" og det gør den 3 gange i sekundet
    ''sætter formens tekst til at vise "taeller" værdien
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        taeller += 1
        Me.Text = taeller
        ''Her starter den en case alt efter hvilken værdi casen har
        Select Case taeller
            ''Her sætter den "lbl_Vo" baggrunds farve til rød
            ''Tænder lampen på K8055 boardet kanal 2
            ''Her sætter den "lbl_Bp" baggrunds farve til rød
            ''Tænder lampen på K8055 boardet kanal 1
            ''Her sætter den "lbl_Færdig" baggrunds farve til rød
            ''Tænder lampen på K8055 boardet kanal 8
            Case 1
                Lbl_Vo.BackColor = Color.Red
                SetDigitalChannel(2)
                Lbl_Bp.BackColor = Color.Red
                SetDigitalChannel(1)
                Lbl_Færdig.BackColor = Color.Red
                SetDigitalChannel(8)

                ''Her sætter den "lbl_Bp" baggrunds farve til grøn
                ''Slukker lampen på K8055 boardet kanal 1
            Case 4
                Lbl_Bp.BackColor = Color.Green
                ClearDigitalChannel(1)

                ''Her tjekker den om teksten i "drik" er "kaffe"
                ''Hvis det er tilfældet, så sætter den baggrundens farven
                'på "lbl_Kd" til rød
                ''Og tænder lampen på K8055 boardet kanal 3

                ''Ellers sætter den "lbl_Td" baggrunds farve til rød
                'Og tænder lampen på K8055 boardet kanal 4
            Case 6

                If drik = "kaffe" Then
                    Lbl_Kd.BackColor = Color.Red
                    SetDigitalChannel(3)
                Else
                    Lbl_Td.BackColor = Color.Red
                    SetDigitalChannel(4)
                End If


                ''Her tjekker den om teksten i "drik" er "kaffe"
                ''Hvis det er tilfældet, så sætter den baggrundens farven
                'på "lbl_Kd" til grøn
                ''Og slukker lampen på K8055 boardet kanal 3

                ''Ellers sætter den "lbl_Td" baggrunds farve til grøn
                ''Og slukker lampen på K8055 boardet kanal 4

                ''Til sidst, så fjerner informationerne i "lbl_Td" og "lbl_Kd"
            Case 12
                If drik = "kaffe" Then
                    Lbl_Kd.BackColor = Color.Green
                    ClearDigitalChannel(3)
                Else
                    Lbl_Td.BackColor = Color.Green
                    ClearDigitalChannel(4)
                End If
                Lbl_Td.Refresh()
                Lbl_Kd.Refresh()

                ''Her tjekker den om "sukker" er mere end 0
                'Hvis den er det, så starter den en løkker, som køre igennem
                'det antal sukker, som man har valgt
                ''Hver gang den har kørt et loop, og sætter "lbl_S" 
                'baggrunds farve til rød.
                'så tænder den K8055 lampen på kanal 6
                'Og venter et halvt sekundt


                ''Hver gang den har kørt et loop, og sætter "lbl_S" 
                'baggrunds farve til grøn.
                'så slukker den K8055 lampen på kanal 6
                'Og venter et halvt sekundt
                If sukker > 0 Then
                    For i = 1 To sukker
                        Lbl_S.BackColor = Color.Red
                        Lbl_S.Refresh()
                        SetDigitalChannel(6)
                        Threading.Thread.Sleep(500)
                        Lbl_S.BackColor = Color.Green
                        Lbl_S.Refresh()
                        ClearDigitalChannel(6)
                        Threading.Thread.Sleep(500)

                    Next
                End If

                ''Her tjekker den om "mælk" er mere end 0
                'Hvis den er det, så starter den en løkker, som køre igennem
                'det antal mælk, som man har valgt
                ''Hver gang den har kørt et loop, og sætter "lbl_M" 
                'baggrunds farve til rød.
                'så tænder den K8055 lampen på kanal 7
                'Og venter et halvt sekundt


                ''Hver gang den har kørt et loop, og sætter "lbl_M" 
                'baggrunds farve til grøn.
                'så slukker den K8055 lampen på kanal 7
                'Og venter et halvt sekundt
                If mælk > 0 Then
                    For i = 1 To mælk
                        Lbl_M.BackColor = Color.Red
                        Lbl_M.Refresh()
                        SetDigitalChannel(7)
                        Threading.Thread.Sleep(500)
                        Lbl_M.BackColor = Color.Green
                        Lbl_M.Refresh()
                        ClearDigitalChannel(7)
                        Threading.Thread.Sleep(500)

                    Next
                End If

                ''Sætter "lbl_Vo" baggrunds farve til grøn
                ''Slukker K8055 lampen på kanal 2
                Lbl_Vo.BackColor = Color.Green
                ClearDigitalChannel(2)

                ''Sætter "lbl_Vd" baggrundsfarve til rød
                ''Tænder K8055 lampen på kanal 5
                Lbl_Vd.BackColor = Color.Red
                SetDigitalChannel(5)


                ''Sætter "lbl_Vd" baggrundsfarve til grøn
                ''slukker K8055 lampen på kanal 5
            Case 20
                Lbl_Vd.BackColor = Color.Green
                ClearDigitalChannel(5)

                ''Sætter "lbl_Display" teksten til "Klar!"
                ''Sætter "lbl_Færdig" baggrunds farve til grøn
                ''Slukker K8055 lampen på kanal 8
            Case 30
                Lbl_Display.Text = "Klar!"
                Lbl_Færdig.BackColor = Color.Green
                ClearDigitalChannel(8)

                ''Viser bedsked boksen med teksten "TAG NU DIN BESTILLING!!!!"
                ''Loader "Form1"
            Case 45
                MsgBox("TAG NU DIN BESTILLING!!!!")
                Form1.Show()

                ''Slukker alle lamper på K8055
            Case 50
                ClearAllDigital

                ''Køre et loop, der tænder K8055 lamperne
                'alt efter hvilken værdi den er nået til
                ''Venter 25 milisekunder
                For index = 1 To 10
                    For i = 1 To 8
                        SetDigitalChannel(i)
                        Threading.Thread.Sleep(25)
                    Next

                    ''Køre et loop, der slukker K8055 lamperne
                    'alt efter hvilken værdi den er nået til
                    ''Venter 25 milisekunder
                    For i = 1 To 8
                        ClearDigitalChannel(i)
                        Threading.Thread.Sleep(25)
                    Next

                    ''Køre et loop, der tænder K8055 lamperne i modsat vej
                    'alt efter hvilken værdi den er nået til
                    ''Venter 25 milisekunder
                    For i = 8 To 1 Step -1
                        SetDigitalChannel(i)
                        Threading.Thread.Sleep(25)
                    Next

                    ''Køre et loop, der slukker K8055 lamperne i modsat vej
                    'alt efter hvilken værdi den er nået til
                    ''Venter 25 milisekunder
                    For i = 8 To 1 Step -1
                        ClearDigitalChannel(i)
                        Threading.Thread.Sleep(25)
                    Next
                Next

                ''Sætter "taeller" til 0
                ''Stopper "Timer1"
                taeller = 0
                Timer1.Stop()

        End Select
    End Sub

    ''Loader "Form1" når denne form lukker
    Private Sub Form_Automat_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Form1.Show()

    End Sub


End Class